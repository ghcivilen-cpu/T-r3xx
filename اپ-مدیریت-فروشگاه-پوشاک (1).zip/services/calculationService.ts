import {
  PROFIT_RATE_SELLING,
  PROFIT_RATE_GENERAL_DISCOUNT,
  PROFIT_RATE_SPECIAL_DISCOUNT,
  INFLATION_RATE_PER_10_MONTHS,
} from '../constants';
import type { ProductMaster, CalculatedPrices } from '../types';
import { getJalaliDateParts } from './dateUtils';

export const calculatePrices = (product: ProductMaster): CalculatedPrices => {
  const purchaseDate = new Date(product.purchase_date);
  const now = new Date();
  
  // Convert dates to Jalali for calculation
  const purchaseJalali = getJalaliDateParts(purchaseDate);
  const nowJalali = getJalaliDateParts(now);

  // Calculate elapsed months based on Jalali calendar
  const monthsElapsed = (nowJalali.jy - purchaseJalali.jy) * 12 + (nowJalali.jm - purchaseJalali.jm);
  
  const n = Math.floor(Math.max(0, monthsElapsed) / 10);
  const inflationMultiplier = (1 + INFLATION_RATE_PER_10_MONTHS) ** n;
  
  const adjusted_purchase_price = product.purchase_price * inflationMultiplier;
  
  const selling_price = Math.round(adjusted_purchase_price * (1 + PROFIT_RATE_SELLING));
  const general_discount_price = Math.round(adjusted_purchase_price * (1 + PROFIT_RATE_GENERAL_DISCOUNT));
  const special_discount_price = Math.round(adjusted_purchase_price * (1 + PROFIT_RATE_SPECIAL_DISCOUNT));

  return {
    selling_price,
    general_discount_price,
    special_discount_price,
    adjusted_purchase_price,
  };
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('fa-IR').format(amount);
};
