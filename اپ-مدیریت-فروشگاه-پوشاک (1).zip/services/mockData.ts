import type { ProductMaster, ProductVariant } from '../types';

// Data is now managed through the UI, starting with an empty inventory.
export const mockProductMasters: ProductMaster[] = [];

export const mockProductVariants: ProductVariant[] = [];
