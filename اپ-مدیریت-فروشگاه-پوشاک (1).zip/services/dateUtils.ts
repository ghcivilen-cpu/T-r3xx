// services/dateUtils.ts

/*
  Functions to convert between Gregorian and Jalali calendars.
  This implementation is self-contained and has no external dependencies.
*/
function toJalali(gy: number, gm: number, gd: number) {
    var g_d_m, j_d_m, jy, jm, jd, gy2, days;
    g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    j_d_m = [0, 31, 62, 93, 124, 155, 186, 216, 246, 276, 306, 336];
    jy = (gy <= 1600) ? 0 : 979;
    gy -= (gy <= 1600) ? 621 : 1600;
    gy2 = (gm > 2) ? (gy + 1) : gy;
    days = (365 * gy) + (Math.floor((gy2 + 3) / 4)) - (Math.floor((gy2 + 99) / 100)) + (Math.floor((gy2 + 399) / 400)) - 80 + gd + g_d_m[gm - 1];
    jy += 33 * (Math.floor(days / 12053));
    days %= 12053;
    jy += 4 * (Math.floor(days / 1461));
    days %= 1461;
    if (days > 365) {
        jy += Math.floor((days - 1) / 365);
        days = (days - 1) % 365;
    }
    jm = (days < 186) ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
    jd = 1 + ((days < 186) ? (days % 31) : ((days - 186) % 30));
    return { jy: jy, jm: jm, jd: jd };
}

function toGregorian(jy: number, jm: number, jd: number) {
    var gy, gm, gd, days;
    gy = (jy <= 979) ? 621 : 1600;
    jy -= (jy <= 979) ? 0 : 979;
    days = (365 * jy) + (Math.floor(jy / 33) * 8) + (Math.floor(((jy % 33) + 3) / 4)) + 78 + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
    gy += 400 * (Math.floor(days / 146097));
    days %= 146097;
    if (days > 36524) {
        gy += 100 * (Math.floor(--days / 36524));
        days %= 36524;
        if (days >= 365) days++;
    }
    gy += 4 * (Math.floor(days / 1461));
    days %= 1461;
    if (days > 365) {
        gy += Math.floor((days - 1) / 365);
        days = (days - 1) % 365;
    }
    gd = days + 1;
    var sal_a = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    if ((gy % 4 == 0 && gy % 100 != 0) || (gy % 400 == 0)) sal_a[2] = 29;
    for (gm = 1; gm <= 12; gm++) {
        if (gd <= sal_a[gm]) break;
        gd -= sal_a[gm];
    }
    return { gy: gy, gm: gm, gd: gd };
}

/**
 * Formats a Date object or ISO string into a Jalali date string (e.g., "1403/05/15").
 */
export const formatToJalali = (date: Date | string): string => {
  const d = typeof date === 'string' ? new Date(date) : date;
  if (isNaN(d.getTime())) return '';
  const gYear = d.getFullYear();
  const gMonth = d.getMonth() + 1;
  const gDay = d.getDate();
  const { jy, jm, jd } = toJalali(gYear, gMonth, gDay);
  return `${jy}/${String(jm).padStart(2, '0')}/${String(jd).padStart(2, '0')}`;
};

/**
 * Parses a Jalali date string (e.g., "1403/05/15") and returns a Date object.
 * Returns null if the format is invalid.
 */
export const parseFromJalali = (jalaliStr: string): Date | null => {
  if (!jalaliStr || !/^\d{4}\/?\d{1,2}\/?\d{1,2}$/.test(jalaliStr.replace(/\s/g, ''))) {
    return null;
  }
  const parts = jalaliStr.split('/').map(Number);
  if (parts.length !== 3 || parts.some(isNaN)) {
    return null;
  }
  const [jy, jm, jd] = parts;
  
  if (jm < 1 || jm > 12 || jd < 1 || jd > 31 || (jm > 6 && jd > 30)) {
      return null;
  }
  // Leap year check for Esfand (month 12)
  const isLeap = (((jy + 1) % 33) % 4) === 1;
  if (jm === 12 && jd > (isLeap ? 30 : 29)) {
      return null;
  }

  const { gy, gm, gd } = toGregorian(jy, jm, jd);
  const resultDate = new Date(gy, gm - 1, gd);
  // Also set time to avoid timezone issues with date-only strings
  resultDate.setHours(0,0,0,0);
  return resultDate;
};

/**
 * Converts a JS Date object to a Jalali date object { jy, jm, jd }.
 * Needed for calculations.
 */
export const getJalaliDateParts = (date: Date): { jy: number, jm: number, jd: number } => {
    const gYear = date.getFullYear();
    const gMonth = date.getMonth() + 1;
    const gDay = date.getDate();
    return toJalali(gYear, gMonth, gDay);
}
