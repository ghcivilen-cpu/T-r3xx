import React, { useState, useMemo, useEffect } from 'react';
import type { ProductMaster, ProductVariant, SaleItem, CalculatedPrices, SaleOrder } from '../types';
import { PriceType } from '../types';
import { calculatePrices, formatCurrency } from '../services/calculationService';
import { TrashIcon, SalesIcon } from './icons';

interface SaleProductCardProps {
    product: ProductMaster;
    prices: CalculatedPrices;
    onAddToCart: () => void;
}

const SaleProductCard: React.FC<SaleProductCardProps> = ({ product, prices, onAddToCart }) => {
    return (
        <div className="bg-white rounded-lg shadow-md overflow-hidden cursor-pointer group transition-shadow hover:shadow-xl" onClick={onAddToCart}>
            <div className="overflow-hidden">
                <img src={product.images[0] || 'https://via.placeholder.com/400'} alt={product.product_name} className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300" />
            </div>
            <div className="p-4">
                <h3 className="font-bold text-lg text-gray-800 truncate">{product.product_name}</h3>
                <p className="text-sm text-gray-500">{product.category}</p>
                <div className="mt-3 space-y-1 text-sm">
                    <div className="flex justify-between items-center bg-blue-50 p-1 rounded">
                        <span className="text-blue-800">فروش عادی:</span>
                        <span className="font-semibold text-blue-800">{formatCurrency(prices.selling_price)}</span>
                    </div>
                    <div className="flex justify-between items-center bg-green-50 p-1 rounded">
                        <span className="text-green-800">تخفیف عمومی:</span>
                        <span className="font-semibold text-green-800">{formatCurrency(prices.general_discount_price)}</span>
                    </div>
                    <div className="flex justify-between items-center bg-yellow-50 p-1 rounded">
                        <span className="text-yellow-800">تخفیف ویژه:</span>
                        <span className="font-semibold text-yellow-800">{formatCurrency(prices.special_discount_price)}</span>
                    </div>
                </div>
            </div>
        </div>
    );
};


interface CartProps {
    cart: SaleItem[];
    products: ProductMaster[];
    variants: ProductVariant[];
    onRemoveItem: (itemId: string) => void;
    onCheckout: (finalAmount: number) => void;
    onUpdateItem: (itemId: string, newPriceType: PriceType) => void;
}

const Cart: React.FC<CartProps> = ({ cart, products, variants, onRemoveItem, onCheckout, onUpdateItem }) => {
    const cartTotal = useMemo(() => {
        return cart.reduce((sum, item) => sum + (item.unit_price_at_time_of_sale * item.quantity), 0);
    }, [cart]);

    const [finalAmount, setFinalAmount] = useState<number>(cartTotal);
    
    useEffect(() => {
        setFinalAmount(cartTotal);
    }, [cartTotal]);

    const handleCheckout = () => {
        onCheckout(finalAmount);
    }
    
    if (cart.length === 0) {
        return (
            <div className="bg-white p-6 rounded-lg shadow-lg h-full flex flex-col items-center justify-center">
                <SalesIcon className="w-16 h-16 text-gray-300 mb-4" />
                <h3 className="text-lg font-semibold text-gray-500">سبد خرید خالی است</h3>
                <p className="text-sm text-gray-400 mt-1">محصولات مورد نظر خود را از لیست انتخاب کنید.</p>
            </div>
        )
    }

    return (
        <div className="bg-white rounded-lg shadow-lg h-full flex flex-col">
            <h2 className="text-xl font-bold p-4 border-b">سبد خرید</h2>
            <div className="flex-grow overflow-y-auto p-3 space-y-3 bg-gray-50">
                 {cart.map(item => {
                    const variant = variants.find(v => v.id === item.product_variant_id);
                    const product = products.find(p => p.id === item.product_master_id);
                    if (!variant || !product) return null;

                    return (
                        <div key={item.id} className="flex items-start gap-3 p-3 bg-white rounded-lg shadow-sm border border-gray-200">
                            <img src={product.images[0] || 'https://via.placeholder.com/150'} alt={product.product_name} className="w-16 h-16 object-cover rounded-md flex-shrink-0" />
                            <div className="flex-grow">
                                <p className="font-bold text-gray-800 text-sm">{product.product_name}</p>
                                <p className="text-xs text-gray-500">سایز: {variant.size_label} | تعداد: {item.quantity}</p>
                                <p className="text-sm text-gray-700 mt-1 font-semibold">{formatCurrency(item.unit_price_at_time_of_sale)} <span className="text-xs">تومان</span></p>

                                <div className="mt-2 flex items-center gap-1 text-xs">
                                    <button onClick={() => onUpdateItem(item.id, PriceType.Selling)} className={`px-2 py-0.5 rounded-full border transition-colors ${item.unit_price_selected_type === PriceType.Selling ? 'border-blue-500 bg-blue-500 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>عادی</button>
                                    <button onClick={() => onUpdateItem(item.id, PriceType.GeneralDiscount)} className={`px-2 py-0.5 rounded-full border transition-colors ${item.unit_price_selected_type === PriceType.GeneralDiscount ? 'border-green-500 bg-green-500 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>عمومی</button>
                                    <button onClick={() => onUpdateItem(item.id, PriceType.SpecialDiscount)} className={`px-2 py-0.5 rounded-full border transition-colors ${item.unit_price_selected_type === PriceType.SpecialDiscount ? 'border-yellow-500 bg-yellow-500 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>ویژه</button>
                                </div>
                            </div>
                             <button onClick={() => onRemoveItem(item.id)} className="text-gray-400 hover:text-red-600 transition-colors flex-shrink-0">
                                <TrashIcon className="w-5 h-5"/>
                            </button>
                        </div>
                    )
                 })}
            </div>
            <div className="p-4 border-t">
                <div className="space-y-2 mb-4 text-lg">
                    <div className="flex justify-between font-bold">
                        <span className="text-gray-700">جمع کل:</span>
                        <span className="text-blue-600">{formatCurrency(cartTotal)} تومان</span>
                    </div>
                </div>
                <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-700">مبلغ نهایی پرداخت (تومان)</label>
                    <input 
                        type="number"
                        value={finalAmount}
                        onChange={(e) => setFinalAmount(Number(e.target.value))}
                        className="w-full p-2 border rounded-md mt-1 text-lg font-bold"
                    />
                </div>
                <button onClick={handleCheckout} className="w-full bg-green-600 text-white p-3 rounded-lg mt-4 font-bold hover:bg-green-700 transition-all duration-200 transform hover:scale-105">نهایی‌سازی خرید</button>
            </div>
        </div>
    );
};


interface AddToCartModalProps {
  product: ProductMaster;
  variants: ProductVariant[];
  prices: CalculatedPrices;
  onClose: () => void;
  onConfirm: (item: Omit<SaleItem, 'id'>) => void;
  cart: SaleItem[];
}

const AddToCartModal: React.FC<AddToCartModalProps> = ({ product, variants, prices, onClose, onConfirm, cart }) => {
    const getInitialVariantId = () => {
        const firstAvailable = variants.find(v => {
            const inCart = cart.filter(item => item.product_variant_id === v.id).reduce((sum, item) => sum + item.quantity, 0);
            return v.quantity - inCart > 0;
        });
        return firstAvailable?.id || variants[0]?.id || '';
    };

    const [selectedVariantId, setSelectedVariantId] = useState<string>(getInitialVariantId);
    const [quantity, setQuantity] = useState(1);
    const [priceType, setPriceType] = useState<PriceType>(PriceType.Selling);

    const { availableStock, selectedVariant } = useMemo(() => {
        const variant = variants.find(v => v.id === selectedVariantId);
        if (!variant) return { availableStock: 0, selectedVariant: null };

        const quantityInCart = cart
            .filter(item => item.product_variant_id === selectedVariantId)
            .reduce((sum, item) => sum + item.quantity, 0);
            
        return { 
            availableStock: variant.quantity - quantityInCart,
            selectedVariant: variant
        };
    }, [selectedVariantId, variants, cart]);
    
    useEffect(() => {
        setQuantity(1); // Reset quantity when size changes
    }, [selectedVariantId]);
    
    const handleConfirm = () => {
        if (!selectedVariant || quantity <= 0) return;

        let unit_price_at_time_of_sale = 0;
        switch (priceType) {
            case PriceType.Selling: unit_price_at_time_of_sale = prices.selling_price; break;
            case PriceType.GeneralDiscount: unit_price_at_time_of_sale = prices.general_discount_price; break;
            case PriceType.SpecialDiscount: unit_price_at_time_of_sale = prices.special_discount_price; break;
        }

        onConfirm({
            product_variant_id: selectedVariant.id,
            product_master_id: product.id,
            quantity: quantity,
            unit_price_at_time_of_sale,
            unit_price_selected_type: priceType,
            adjusted_purchase_price: prices.adjusted_purchase_price,
        });
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
                <h2 className="text-xl font-bold mb-4">{product.product_name}</h2>
                <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700">سایز</label>
                    <select value={selectedVariantId} onChange={e => setSelectedVariantId(e.target.value)} className="w-full p-2 border rounded-md mt-1">
                        {variants.map(v => {
                            const inCart = cart.filter(item => item.product_variant_id === v.id).reduce((sum, item) => sum + item.quantity, 0);
                            const stock = v.quantity - inCart;
                            return <option key={v.id} value={v.id} disabled={stock <= 0}>{v.size_label} (موجودی: {stock})</option>
                        })}
                    </select>
                </div>
                <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700">تعداد</label>
                    <input 
                        type="number"
                        value={quantity}
                        onChange={e => setQuantity(Math.max(1, Math.min(Number(e.target.value), availableStock)))}
                        min="1"
                        max={availableStock}
                        className="w-full p-2 border rounded-md mt-1"
                        disabled={availableStock <= 0}
                    />
                </div>
                 <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700">نوع قیمت</label>
                    <div className="mt-2 grid grid-cols-3 gap-2">
                        <button onClick={() => setPriceType(PriceType.Selling)} className={`p-2 rounded-md border transition-colors ${priceType === PriceType.Selling ? 'bg-blue-500 text-white' : 'bg-gray-100 hover:bg-gray-200'}`}>عادی</button>
                        <button onClick={() => setPriceType(PriceType.GeneralDiscount)} className={`p-2 rounded-md border transition-colors ${priceType === PriceType.GeneralDiscount ? 'bg-green-500 text-white' : 'bg-gray-100 hover:bg-gray-200'}`}>عمومی</button>
                        <button onClick={() => setPriceType(PriceType.SpecialDiscount)} className={`p-2 rounded-md border transition-colors ${priceType === PriceType.SpecialDiscount ? 'bg-yellow-500 text-white' : 'bg-gray-100 hover:bg-gray-200'}`}>ویژه</button>
                    </div>
                </div>
                <div className="flex justify-end gap-4">
                    <button onClick={onClose} className="px-4 py-2 bg-gray-200 rounded-md hover:bg-gray-300">انصراف</button>
                    <button onClick={handleConfirm} disabled={availableStock <= 0 || quantity <= 0} className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed">افزودن به سبد</button>
                </div>
            </div>
        </div>
    );
};



interface SalesPageProps {
  products: ProductMaster[];
  variants: ProductVariant[];
  cart: SaleItem[];
  setCart: React.Dispatch<React.SetStateAction<SaleItem[]>>;
  setVariants: React.Dispatch<React.SetStateAction<ProductVariant[]>>;
  setSales: React.Dispatch<React.SetStateAction<SaleOrder[]>>;
}

const SalesPage: React.FC<SalesPageProps> = ({ products, variants, cart, setCart, setVariants, setSales }) => {
  const [modalProduct, setModalProduct] = useState<ProductMaster | null>(null);

  const handleAddToCart = (item: Omit<SaleItem, 'id'>) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(i => i.product_variant_id === item.product_variant_id && i.unit_price_selected_type === item.unit_price_selected_type);
      if (existingItem) {
        return prevCart.map(i => i.id === existingItem.id ? {...i, quantity: i.quantity + item.quantity} : i);
      }
      return [...prevCart, { ...item, id: `si${Date.now()}` }];
    });
    setModalProduct(null);
  };
  
  const handleRemoveFromCart = (itemId: string) => {
    setCart(prevCart => prevCart.filter(item => item.id !== itemId));
  };
  
  const handleUpdateCartItem = (itemId: string, newPriceType: PriceType) => {
    setCart(prevCart => {
        return prevCart.map(item => {
            if (item.id === itemId) {
                const product = products.find(p => p.id === item.product_master_id);
                if (!product) return item;

                const prices = calculatePrices(product);
                let newUnitPrice = 0;
                switch (newPriceType) {
                    case PriceType.Selling: newUnitPrice = prices.selling_price; break;
                    case PriceType.GeneralDiscount: newUnitPrice = prices.general_discount_price; break;
                    case PriceType.SpecialDiscount: newUnitPrice = prices.special_discount_price; break;
                }

                return {
                    ...item,
                    unit_price_selected_type: newPriceType,
                    unit_price_at_time_of_sale: newUnitPrice,
                };
            }
            return item;
        });
    });
  };

  const handleCheckout = (finalAmount: number) => {
    if (cart.length === 0) return;

    // 1. Calculate profit
    const totalAdjustedCost = cart.reduce((sum, item) => sum + (item.adjusted_purchase_price * item.quantity), 0);
    const profit = finalAmount - totalAdjustedCost;
    
    // 2. Create Sale Order
    const newSale: SaleOrder = {
        id: `so${Date.now()}`,
        items: cart,
        final_paid_amount: finalAmount,
        sale_date: new Date().toISOString(),
        profit,
    };
    setSales(prev => [...prev, newSale]);

    // 3. Decrement stock
    const newVariants = [...variants];
    cart.forEach(item => {
        const variantIndex = newVariants.findIndex(v => v.id === item.product_variant_id);
        if (variantIndex !== -1) {
            newVariants[variantIndex].quantity -= item.quantity;
        }
    });
    setVariants(newVariants);

    // 4. Clear cart
    setCart([]);
    alert('فروش با موفقیت ثبت شد!');
  };


  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 p-6 bg-gray-50 min-h-full">
      <div className="lg:col-span-2">
        <h1 className="text-3xl font-bold text-gray-800 mb-6">فروش</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
          {products.map(product => (
            <SaleProductCard
              key={product.id}
              product={product}
              prices={calculatePrices(product)}
              onAddToCart={() => setModalProduct(product)}
            />
          ))}
        </div>
      </div>
      <div className="lg:col-span-1">
        <Cart 
            cart={cart}
            products={products}
            variants={variants}
            onRemoveItem={handleRemoveFromCart}
            onCheckout={handleCheckout}
            onUpdateItem={handleUpdateCartItem}
        />
      </div>
      {modalProduct && (
        <AddToCartModal 
            product={modalProduct}
            variants={variants.filter(v => v.product_master_id === modalProduct.id)}
            prices={calculatePrices(modalProduct)}
            onClose={() => setModalProduct(null)}
            onConfirm={handleAddToCart}
            cart={cart}
        />
      )}
    </div>
  );
};

export default SalesPage;