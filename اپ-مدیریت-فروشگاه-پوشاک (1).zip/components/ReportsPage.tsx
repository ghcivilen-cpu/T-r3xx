
import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import type { ProductMaster, ProductVariant, SaleOrder } from '../types';
import { INVENTORY_ALERT_THRESHOLD } from '../constants';
import { calculatePrices, formatCurrency } from '../services/calculationService';

interface ReportsPageProps {
  products: ProductMaster[];
  variants: ProductVariant[];
  sales: SaleOrder[];
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

const ReportsPage: React.FC<ReportsPageProps> = ({ products, variants, sales }) => {
  const weeklySalesData = useMemo(() => {
    const data: { name: string; فروش: number }[] = [];
    const days = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];
    const today = new Date();
    for (let i = 6; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(today.getDate() - i);
        const dayName = days[date.getDay() % 7]; // Adjust for locale
        const dailySales = sales
            .filter(s => new Date(s.sale_date).toDateString() === date.toDateString())
            .reduce((sum, s) => sum + s.final_paid_amount, 0);
        data.push({ name: dayName, فروش: dailySales });
    }
    return data;
  }, [sales]);

  const categorySalesData = useMemo(() => {
    const categoryMap: { [key: string]: number } = {};
    sales.forEach(order => {
      order.items.forEach(item => {
        const product = products.find(p => p.id === item.product_master_id);
        if (product) {
          if (!categoryMap[product.category]) {
            categoryMap[product.category] = 0;
          }
          categoryMap[product.category] += item.unit_price_at_time_of_sale * item.quantity;
        }
      });
    });
    return Object.entries(categoryMap).map(([name, value]) => ({ name, value }));
  }, [sales, products]);

  const lowStockItems = useMemo(() => {
    return variants.filter(v => v.quantity > 0 && v.quantity <= INVENTORY_ALERT_THRESHOLD);
  }, [variants]);

  const totalInventoryValue = useMemo(() => {
    return variants.reduce((total, variant) => {
        const product = products.find(p => p.id === variant.product_master_id);
        if(product) {
            const { adjusted_purchase_price } = calculatePrices(product);
            return total + (adjusted_purchase_price * variant.quantity);
        }
        return total;
    }, 0);
  }, [variants, products]);

  const totalSalesToday = useMemo(() => {
      const todayStr = new Date().toDateString();
      return sales
        .filter(s => new Date(s.sale_date).toDateString() === todayStr)
        .reduce((sum, s) => sum + s.final_paid_amount, 0);
  }, [sales]);


  return (
    <div className="p-6 bg-gray-50 min-h-full">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">داشبورد و گزارشات</h1>
      
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-md border-r-4 border-blue-500">
          <h2 className="text-gray-500 text-lg">فروش امروز</h2>
          <p className="text-3xl font-bold text-gray-800 mt-2">{formatCurrency(totalSalesToday)} <span className="text-sm font-normal">تومان</span></p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md border-r-4 border-green-500">
          <h2 className="text-gray-500 text-lg">ارزش کل موجودی</h2>
          <p className="text-3xl font-bold text-gray-800 mt-2">{formatCurrency(totalInventoryValue)} <span className="text-sm font-normal">تومان</span></p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md border-r-4 border-red-500">
          <h2 className="text-gray-500 text-lg">هشدارهای کمبود کالا</h2>
          <p className="text-3xl font-bold text-gray-800 mt-2">{lowStockItems.length} <span className="text-sm font-normal">مورد</span></p>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold text-gray-700 mb-4">فروش هفته اخیر</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={weeklySalesData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis tickFormatter={(value) => formatCurrency(Number(value))} />
              <Tooltip formatter={(value) => [`${formatCurrency(Number(value))} تومان`, 'فروش']} />
              <Legend />
              <Bar dataKey="فروش" fill="#3B82F6" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold text-gray-700 mb-4">سهم فروش دسته‌بندی‌ها</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={categorySalesData}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={110}
                fill="#8884d8"
                dataKey="value"
                nameKey="name"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {categorySalesData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => `${formatCurrency(Number(value))} تومان`} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Low Stock Table */}
       <div className="bg-white p-6 rounded-lg shadow-md">
         <h2 className="text-xl font-semibold text-gray-700 mb-4">لیست کالاهای رو به اتمام</h2>
         <div className="overflow-x-auto">
           <table className="w-full text-right">
             <thead className="bg-gray-100">
               <tr>
                 <th className="p-3">نام محصول</th>
                 <th className="p-3">سایز</th>
                 <th className="p-3">تعداد باقی‌مانده</th>
               </tr>
             </thead>
             <tbody>
               {lowStockItems.length > 0 ? lowStockItems.map(variant => {
                 const product = products.find(p => p.id === variant.product_master_id);
                 return (
                   <tr key={variant.id} className="border-b hover:bg-gray-50">
                     <td className="p-3">{product?.product_name}</td>
                     <td className="p-3">{variant.size_label}</td>
                     <td className="p-3 text-red-600 font-bold">{variant.quantity}</td>
                   </tr>
                 );
               }) : (
                 <tr>
                    <td colSpan={3} className="text-center p-4 text-gray-500">موردی برای نمایش وجود ندارد.</td>
                 </tr>
               )}
             </tbody>
           </table>
         </div>
       </div>

    </div>
  );
};

export default ReportsPage;
