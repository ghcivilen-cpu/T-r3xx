import React, { useState, useEffect } from 'react';
import type { ProductMaster, ProductVariant } from '../types';
import { PlusIcon, TrashIcon, PencilIcon } from './icons';
import { calculatePrices, formatCurrency } from '../services/calculationService';
import { formatToJalali, parseFromJalali } from '../services/dateUtils';

type VariantFormData = Omit<ProductVariant, 'product_master_id'>;

interface ProductFormModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (productData: Omit<ProductMaster, 'id'>, variantsData: VariantFormData[]) => void;
    productToEdit: ProductMaster | null;
    variantsToEdit: ProductVariant[];
}

const ProductFormModal: React.FC<ProductFormModalProps> = ({ isOpen, onClose, onSave, productToEdit, variantsToEdit }) => {
    const getInitialProductData = () => ({
        product_name: '',
        category: '',
        subcategory: '',
        images: [] as string[],
        purchase_date: formatToJalali(new Date()),
        purchase_price: 0,
        color: '',
        description: '',
    });
    
    const [productData, setProductData] = useState(getInitialProductData());
    const [variantsData, setVariantsData] = useState<VariantFormData[]>([]);

    useEffect(() => {
        if (productToEdit) {
            setProductData({
                product_name: productToEdit.product_name,
                category: productToEdit.category,
                subcategory: productToEdit.subcategory,
                images: productToEdit.images,
                purchase_date: formatToJalali(new Date(productToEdit.purchase_date)),
                purchase_price: productToEdit.purchase_price,
                color: productToEdit.color,
                description: productToEdit.description ?? '',
            });
            setVariantsData(variantsToEdit);
        } else {
            setProductData(getInitialProductData());
            setVariantsData([{ id: `temp_${Date.now()}`, size_label: '', quantity: 1 }]);
        }
    }, [productToEdit, variantsToEdit, isOpen]);

    if (!isOpen) return null;

    const handleProductChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        setProductData(prev => ({ ...prev, [name]: type === 'number' ? Number(value) : value }));
    };

    const handleVariantChange = (id: string, field: keyof VariantFormData, value: string | number) => {
        setVariantsData(prev => prev.map(v => v.id === id ? { ...v, [field]: value } : v));
    };
    
    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            for (const file of e.target.files) {
                const reader = new FileReader();
                reader.onloadend = () => {
                    if (typeof reader.result === 'string') {
                        setProductData(prev => ({ ...prev, images: [...prev.images, reader.result as string] }));
                    }
                };
                reader.readAsDataURL(file);
            }
        }
    };

    const handleRemoveImage = (indexToRemove: number) => {
        setProductData(prev => ({
            ...prev,
            images: prev.images.filter((_, index) => index !== indexToRemove),
        }));
    };

    const addVariant = () => {
        setVariantsData(prev => [...prev, { id: `temp_${Date.now()}`, size_label: '', quantity: 1 }]);
    };

    const removeVariant = (id: string) => {
        setVariantsData(prev => prev.filter(v => v.id !== id));
    };

    const handleSave = () => {
        if (!productData.product_name.trim() || !productData.category.trim() || !productData.subcategory.trim()) {
            alert('لطفاً نام محصول، دسته‌بندی و زیرشاخه را تکمیل کنید.');
            return;
        }

        const gregorianDate = parseFromJalali(productData.purchase_date);
        if (!gregorianDate) {
            alert('فرمت تاریخ نامعتبر است. لطفا از فرمت YYYY/MM/DD استفاده کنید.');
            return;
        }
        
        const productDataForSave = {
            ...productData,
            purchase_date: gregorianDate.toISOString(),
        };

        const validVariants = variantsData.filter(v => v.size_label.trim() !== '' && v.quantity > 0);

        if (validVariants.length === 0) {
            alert('باید حداقل یک سایز با تعداد معتبر (بیشتر از صفر) وارد شود.');
            return;
        }

        onSave(productDataForSave, validVariants);
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-3xl max-h-[90vh] flex flex-col">
                <div className="p-4 border-b">
                    <h2 className="text-xl font-bold">{productToEdit ? 'ویرایش محصول' : 'ثبت محصول جدید'}</h2>
                </div>
                <div className="p-6 overflow-y-auto space-y-6">
                    {/* Image Upload Section */}
                    <div>
                        <h3 className="font-semibold mb-2 text-gray-700">تصاویر محصول (اختیاری)</h3>
                        <div className="grid grid-cols-3 sm:grid-cols-5 gap-4">
                            {productData.images.map((imgSrc, index) => (
                                <div key={index} className="relative group aspect-square">
                                    <img src={imgSrc} alt={`تصویر محصول ${index + 1}`} className="w-full h-full object-cover rounded-md border" />
                                    <button onClick={() => handleRemoveImage(index)} className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-lg opacity-0 group-hover:opacity-100 transition-opacity focus:opacity-100">&times;</button>
                                </div>
                            ))}
                            <label htmlFor="imageUpload" className="w-full h-full border-2 border-dashed rounded-md flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 aspect-square">
                                <PlusIcon className="w-8 h-8 text-gray-400" />
                                <span className="text-sm text-gray-500 mt-1">افزودن</span>
                            </label>
                            <input type="file" id="imageUpload" multiple accept="image/*" className="hidden" onChange={handleImageChange} />
                        </div>
                    </div>

                    {/* Product Details */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <input name="product_name" value={productData.product_name} onChange={handleProductChange} placeholder="نام محصول (الزامی)" className="p-2 border rounded-md" />
                        <input name="category" value={productData.category} onChange={handleProductChange} placeholder="دسته‌بندی (الزامی)" className="p-2 border rounded-md" />
                        <input name="subcategory" value={productData.subcategory} onChange={handleProductChange} placeholder="زیرشاخه (الزامی)" className="p-2 border rounded-md" />
                        <input name="color" value={productData.color} onChange={handleProductChange} placeholder="رنگ" className="p-2 border rounded-md" />
                        <input name="purchase_price" type="number" value={productData.purchase_price || ''} onChange={handleProductChange} placeholder="قیمت خرید (تومان)" className="p-2 border rounded-md" />
                        <input 
                            name="purchase_date" 
                            type="text" 
                            value={productData.purchase_date} 
                            onChange={handleProductChange} 
                            placeholder="تاریخ خرید (مثال: 1403/05/15)" 
                            className="p-2 border rounded-md text-left"
                            dir="ltr"
                        />
                    </div>
                    <textarea name="description" value={productData.description} onChange={handleProductChange} placeholder="توضیحات (اختیاری)" className="p-2 border rounded-md w-full min-h-[80px]"></textarea>

                    {/* Variants Section */}
                    <div className="border-t pt-4">
                        <h3 className="font-semibold mb-2">سایزها و موجودی (حداقل یک مورد الزامی)</h3>
                        {variantsData.map((v) => (
                            <div key={v.id} className="flex items-center gap-2 mb-2">
                                <input value={v.size_label} onChange={(e) => handleVariantChange(v.id, 'size_label', e.target.value)} placeholder="سایز (مثلا L)" className="p-2 border rounded-md flex-1" />
                                <input type="number" value={v.quantity} onChange={(e) => handleVariantChange(v.id, 'quantity', Number(e.target.value))} placeholder="تعداد" className="p-2 border rounded-md w-24" min="0" />
                                <button onClick={() => removeVariant(v.id)} className="p-2 text-red-500 hover:bg-red-100 rounded-md">
                                    <TrashIcon className="w-5 h-5" />
                                </button>
                            </div>
                        ))}
                        <button onClick={addVariant} className="text-blue-600 font-semibold mt-2 hover:underline">افزودن سایز +</button>
                    </div>
                </div>
                <div className="p-4 flex justify-end gap-4 bg-gray-50 border-t">
                    <button onClick={onClose} className="px-4 py-2 bg-gray-200 rounded-md hover:bg-gray-300">انصراف</button>
                    <button onClick={handleSave} className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">ذخیره</button>
                </div>
            </div>
        </div>
    );
};


interface ProductCardProps {
    product: ProductMaster;
    variants: ProductVariant[];
    onEdit: (product: ProductMaster) => void;
    onDelete: (productId: string) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, variants, onEdit, onDelete }) => {
    const { selling_price } = calculatePrices(product);
    const primaryImage = product.images[0] || 'https://via.placeholder.com/400';

    return (
        <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform transform hover:-translate-y-1 relative group">
            <div className="absolute top-2 left-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                <button onClick={() => onEdit(product)} className="bg-white p-2 rounded-full shadow hover:bg-gray-100" aria-label="ویرایش محصول">
                    <PencilIcon className="w-5 h-5 text-blue-600"/>
                </button>
                <button onClick={() => onDelete(product.id)} className="bg-white p-2 rounded-full shadow hover:bg-gray-100" aria-label="حذف محصول">
                    <TrashIcon className="w-5 h-5 text-red-600"/>
                </button>
            </div>
            <img src={primaryImage} alt={product.product_name} className="w-full h-48 object-cover" />
            <div className="p-4">
                <h3 className="font-bold text-lg text-gray-800">{product.product_name}</h3>
                <p className="text-sm text-gray-500">{product.category} / {product.subcategory}</p>
                <p className="text-sm text-gray-600 mt-1">رنگ: {product.color || '-'}</p>
                 <div className="mt-4">
                    <p className="text-sm text-gray-500">قیمت فروش عادی:</p>
                    <p className="font-semibold text-blue-600 text-lg">{formatCurrency(selling_price)} تومان</p>
                </div>
                <div className="mt-4">
                    <h4 className="font-semibold text-sm text-gray-700 mb-2">موجودی سایزها:</h4>
                    <div className="space-y-1 max-h-24 overflow-y-auto">
                        {variants.map(v => (
                            <div key={v.id} className="flex justify-between text-sm">
                                <span className="text-gray-600">{v.size_label}:</span>
                                <span className="font-bold text-gray-800">{v.quantity} عدد</span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};


interface InventoryPageProps {
  products: ProductMaster[];
  variants: ProductVariant[];
  onAddProduct: (productData: Omit<ProductMaster, 'id'>, variantsData: Omit<VariantFormData, 'id'>[]) => void;
  onUpdateProduct: (product: ProductMaster, variants: ProductVariant[]) => void;
  onDeleteProduct: (productId: string) => void;
}

const InventoryPage: React.FC<InventoryPageProps> = ({ products, variants, onAddProduct, onUpdateProduct, onDeleteProduct }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<ProductMaster | null>(null);

  const handleOpenAddModal = () => {
    setEditingProduct(null);
    setIsModalOpen(true);
  };
  
  const handleOpenEditModal = (product: ProductMaster) => {
    setEditingProduct(product);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingProduct(null);
  };
  
  const handleSaveProduct = (productData: Omit<ProductMaster, 'id'>, variantsData: VariantFormData[]) => {
    if (editingProduct) {
        const updatedProductMaster: ProductMaster = {
            ...editingProduct,
            ...productData,
        };
        const finalVariants: ProductVariant[] = variantsData.map(v => ({
            ...v,
            product_master_id: editingProduct.id
        }));
        onUpdateProduct(updatedProductMaster, finalVariants);
    } else {
        onAddProduct(productData, variantsData.map(({id, ...rest}) => rest));
    }
    handleCloseModal();
  };

  const handleDelete = (productId: string) => {
      if (window.confirm('آیا از حذف این محصول اطمینان دارید؟ این عمل قابل بازگشت نیست.')) {
          onDeleteProduct(productId);
      }
  };


  return (
    <div className="p-6 bg-gray-50 min-h-full">
        <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold text-gray-800">انبارداری</h1>
            <button onClick={handleOpenAddModal} className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg shadow hover:bg-blue-700 transition">
                <PlusIcon className="w-5 h-5" />
                <span>ثبت محصول جدید</span>
            </button>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.length > 0 ? (
                products.map(product => (
                    <ProductCard 
                        key={product.id}
                        product={product} 
                        variants={variants.filter(v => v.product_master_id === product.id)} 
                        onEdit={handleOpenEditModal}
                        onDelete={handleDelete}
                    />
                ))
            ) : (
                 <div className="col-span-full text-center py-16 bg-white rounded-lg shadow-sm">
                    <p className="text-gray-500 text-lg">هیچ محصولی ثبت نشده است.</p>
                    <p className="text-gray-400 mt-2">برای شروع، یک محصول جدید اضافه کنید.</p>
                </div>
            )}
        </div>

        <ProductFormModal 
            isOpen={isModalOpen}
            onClose={handleCloseModal}
            onSave={handleSaveProduct}
            productToEdit={editingProduct}
            variantsToEdit={editingProduct ? variants.filter(v => v.product_master_id === editingProduct.id) : []}
        />
    </div>
  );
};

export default InventoryPage;